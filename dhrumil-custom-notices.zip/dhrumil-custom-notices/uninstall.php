<?php

/**
 * @link       https://www.dhrumilcustomnotices.com
 * @since      1.0.0
 *
 * @package    Dhrumil_Custom_Notices
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
