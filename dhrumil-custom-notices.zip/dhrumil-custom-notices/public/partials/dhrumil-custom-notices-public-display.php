<?php

/**
 * @package    Dhrumil_Custom_Notices
 * @subpackage Dhrumil_Custom_Notices/public/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
