<?php

/**
 * @since      1.0.0
 * @package    Dhrumil_Custom_Notices
 * @subpackage Dhrumil_Custom_Notices/includes
 * @author     Dhrumil Chauhan <dhrumilchauhan708@gmail.com>
 */

class Dhrumil_Custom_Notices_Deactivator {

	public static function deactivate() {

	}

}
